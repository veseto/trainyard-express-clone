import TrainyardGame from './components/TrainyardGame';

function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">
      <TrainyardGame />
    </div>
  );
}

export default App;